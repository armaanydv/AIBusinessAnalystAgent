"""
Core retrieval evaluation engine.
"""

from __future__ import annotations

from time import perf_counter

from app.evaluation.evaluation_models import (
    BenchmarkQuestion,
    BenchmarkReport,
    QuestionEvaluation,
)
from app.evaluation.metrics import (
    calculate_average_latency,
    calculate_hit_rate,
    calculate_precision_at_k,
    calculate_recall_at_k,
    calculate_reciprocal_rank,
)
from app.retrieval.retriever.base_retriever import BaseRetriever


class RetrievalEvaluator:
    """
    Evaluates a retriever against a benchmark dataset.
    """

    def __init__(
        self,
        retriever: BaseRetriever,
        retrieval_k: int = 5,
    ) -> None:

        self._retriever = retriever
        self._retrieval_k = retrieval_k

    def evaluate(
        self,
        benchmark_questions: list[BenchmarkQuestion],
    ) -> BenchmarkReport:
        """
        Evaluate all benchmark questions.
        """

        evaluations: list[QuestionEvaluation] = []

        for question in benchmark_questions:
            evaluations.append(
                self._evaluate_question(question)
            )

        total_questions = len(evaluations)

        if total_questions == 0:
            return BenchmarkReport(
                total_questions=0,
                recall_at_1=0.0,
                recall_at_5=0.0,
                precision_at_5=0.0,
                mrr=0.0,
                hit_rate=0.0,
                average_latency_ms=0.0,
                evaluations=[],
            )

        return BenchmarkReport(
            total_questions=total_questions,
            recall_at_1=sum(
                e.recall_at_1
                for e in evaluations
            )
            / total_questions,
            recall_at_5=sum(
                e.recall_at_5
                for e in evaluations
            )
            / total_questions,
            precision_at_5=sum(
                e.precision_at_5
                for e in evaluations
            )
            / total_questions,
            mrr=sum(
                e.reciprocal_rank
                for e in evaluations
            )
            / total_questions,
            hit_rate=sum(
                e.hit
                for e in evaluations
            )
            / total_questions,
            average_latency_ms=calculate_average_latency(
                [
                    e.latency_ms
                    for e in evaluations
                ]
            ),
            evaluations=evaluations,
        )

    def _evaluate_question(
        self,
        question: BenchmarkQuestion,
    ) -> QuestionEvaluation:
        """
        Evaluate a single benchmark question.
        """

        start = perf_counter()

        results = self._retriever.retrieve(
            query=question.question,
            k=self._retrieval_k,
        )

        latency_ms = (perf_counter() - start) * 1000

        return QuestionEvaluation(
            question=question,
            retrieved_results=results,
            recall_at_1=calculate_recall_at_k(
                question.expected_chunk_ids,
                results,
                k=1,
            ),
            recall_at_5=calculate_recall_at_k(
                question.expected_chunk_ids,
                results,
                k=5,
            ),
            precision_at_5=calculate_precision_at_k(
                question.expected_chunk_ids,
                results,
                k=5,
            ),
            reciprocal_rank=calculate_reciprocal_rank(
                question.expected_chunk_ids,
                results,
            ),
            hit=bool(
                calculate_hit_rate(
                    question.expected_chunk_ids,
                    results,
                    k=5,
                )
            ),
            latency_ms=latency_ms,
        )